import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { Ingredient, Recipe, RecipeItem } from './types';
import { useFirestoreData } from './hooks/useFirestoreData';
import { useVoiceCommands } from './hooks/useVoiceCommands';
import { deleteIngredientFromDB, saveIngredientToDB, deleteRecipeFromDB, saveRecipeToDB } from './services/api';

import { LoaderCircle, Book } from 'lucide-react';
import { Card } from './components/ui/Card';
import { VoiceStatusIndicator } from './components/ui/VoiceStatusIndicator';
import { IngredientManager } from './components/IngredientManager';
import { RecipeManager } from './components/RecipeManager';
import { RecipeDetailView } from './components/RecipeDetailView';
import { IngredientFormModal } from './components/modals/IngredientFormModal';
import { RecipeFormModal } from './components/modals/RecipeFormModal';
import { RecipeItemFormModal } from './components/modals/RecipeItemFormModal';

// MAIN APPLICATION COMPONENT
export default function App() {
    const { isLoading, ingredients, recipes } = useFirestoreData();
    const [isSubmitting, setIsSubmitting] = useState(false);
    
    const [selectedRecipeId, setSelectedRecipeId] = useState<string | null>(null);
    
    const [isIngredientModalOpen, setIngredientModalOpen] = useState(false);
    const [ingredientToEdit, setIngredientToEdit] = useState<Ingredient | null>(null);

    const [isRecipeModalOpen, setRecipeModalOpen] = useState(false);
    const [recipeToEdit, setRecipeToEdit] = useState<Recipe | null>(null);

    const [isItemModalOpen, setItemModalOpen] = useState(false);
    const [itemToEdit, setItemToEdit] = useState<RecipeItem | null>(null);

    const ingredientsList = useMemo(() => Array.from(ingredients.values()), [ingredients]);
    const recipesList = useMemo(() => Array.from(recipes.values()), [recipes]);
    const selectedRecipe = useMemo(() => selectedRecipeId ? recipes.get(selectedRecipeId) : null, [selectedRecipeId, recipes]);
    
    const openIngredientModal = useCallback((ingredient: Ingredient | null = null) => {
        setIngredientToEdit(ingredient);
        setIngredientModalOpen(true);
    }, []);
    
    const openRecipeModal = useCallback((recipe: Recipe | null = null) => {
        setRecipeToEdit(recipe);
        setRecipeModalOpen(true);
    }, []);

    const { voiceStatus, handleListen } = useVoiceCommands({ openIngredientModal, openRecipeModal });

    // Effect for managing selected recipe based on available recipes
    useEffect(() => {
        if (recipesList.length === 0) {
            setSelectedRecipeId(null);
            return;
        }

        if (selectedRecipeId === null || !recipes.has(selectedRecipeId)) {
            const complexRecipe = recipesList.find(r => r.id === 'rec2') || recipesList[0];
            if (complexRecipe) setSelectedRecipeId(complexRecipe.id);
        }
    }, [recipes, recipesList, selectedRecipeId]);

    const handleSaveIngredient = async (ingredient: Ingredient) => {
        if (isSubmitting) return;
        setIsSubmitting(true);
    
        try {
            const normalizedNewName = ingredient.name.trim().toLowerCase();
            const isDuplicate = ingredientsList.some(
                (i) => i.name.trim().toLowerCase() === normalizedNewName && i.id !== ingredient.id
            );
    
            if (isDuplicate) {
                alert(`Ya existe un ingrediente con el nombre "${ingredient.name}". Por favor, elige un nombre diferente.`);
                return; // Early return, `finally` will still execute.
            }
            
            await saveIngredientToDB(ingredient);
            
            // On success, close the modal.
            setIngredientModalOpen(false);
            setIngredientToEdit(null);
        } catch (error) {
            console.error("Error al guardar el ingrediente:", error);
            alert("No se pudo guardar el ingrediente. Intente de nuevo.");
        } finally {
            // This will always run, even on early return from the try block.
            setIsSubmitting(false);
        }
    };
    
    const handleDeleteIngredient = async (id: string) => {
        const isUsed = recipesList.some(r => r.items.some(i => i.type === 'ingredient' && i.ingredientId === id));
        if (isUsed) {
            alert('Este ingrediente no se puede eliminar porque está siendo utilizado en una o más recetas.');
            return;
        }
        try {
            await deleteIngredientFromDB(id);
        } catch (error) {
            console.error("Error al eliminar el ingrediente:", error);
            alert("No se pudo eliminar el ingrediente. Intente de nuevo.");
        }
    };

    const handleSaveRecipe = async (recipe: Recipe) => {
        if (isSubmitting) return;
        setIsSubmitting(true);
    
        try {
            const normalizedNewName = recipe.name.trim().toLowerCase();
            const isDuplicate = recipesList.some(
                (r) => r.name.trim().toLowerCase() === normalizedNewName && r.id !== recipe.id
            );
        
            if (isDuplicate) {
                alert(`Ya existe una receta con el nombre "${recipe.name}". Por favor, elige un nombre diferente.`);
                return; // Early return, `finally` will still execute
            }
            
            await saveRecipeToDB(recipe);
            
            if (!selectedRecipeId || recipe.id === selectedRecipeId) {
                setSelectedRecipeId(recipe.id);
            }
            
            // On success, close the modal.
            setRecipeModalOpen(false);
            setRecipeToEdit(null);
        } catch (error) {
            console.error("Error al guardar la receta:", error);
            alert("No se pudo guardar la receta. Intente de nuevo.");
        } finally {
            // This will always run, re-enabling the button.
            setIsSubmitting(false);
        }
    };

    const handleDeleteRecipe = async (id: string) => {
        const isUsed = recipesList.some(r => r.items.some(i => i.type === 'recipe' && i.recipeId === id));
        if (isUsed) {
            alert('Esta receta no se puede eliminar porque es una sub-receta en otra receta.');
            return;
        }

        try {
            await deleteRecipeFromDB(id);
        } catch (error) {
             console.error("Error al eliminar la receta:", error);
            alert("No se pudo eliminar la receta. Intente de nuevo.");
        }
    };
    
    const handleSaveItem = async (item: RecipeItem) => {
        if (!selectedRecipe || isSubmitting) return;
        setIsSubmitting(true);

        try {
            const updatedItems = itemToEdit
                ? selectedRecipe.items.map(i => (i.id === item.id ? item : i))
                : [...selectedRecipe.items, item];
            
            await saveRecipeToDB({ ...selectedRecipe, items: updatedItems });
            
            // On success, close modal
            setItemModalOpen(false);
            setItemToEdit(null);
        } catch(error) {
            console.error("Error al guardar el elemento de la receta:", error);
            alert("No se pudo guardar el elemento. Intente de nuevo.");
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleDeleteItem = async (itemId: string) => {
        if (!selectedRecipe) return;
        try {
            const updatedItems = selectedRecipe.items.filter(i => i.id !== itemId);
            await saveRecipeToDB({ ...selectedRecipe, items: updatedItems });
        } catch (error) {
            console.error("Error al eliminar el elemento de la receta:", error);
            alert("No se pudo eliminar el elemento. Intente de nuevo.");
        }
    };

    const handleUpdateRecipeDetails = (field: keyof Recipe, value: string | number) => {
        if(!selectedRecipe) return;
        handleSaveRecipe({ ...selectedRecipe, [field]: Number(value) });
    };

    const openItemModal = (item: RecipeItem | null = null) => {
        setItemToEdit(item);
        setItemModalOpen(true);
    };
    
    if (isLoading) {
        return (
            <div className="flex justify-center items-center min-h-screen bg-amber-50/50">
                <div className="flex flex-col items-center gap-4">
                    <LoaderCircle size={48} className="text-amber-500 animate-spin" />
                    <p className="text-amber-800 font-semibold">Conectando con la cocina...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-amber-50/50 font-sans">
            <header className="bg-white shadow-md sticky top-0 z-40">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
                    <h1 className="text-2xl font-bold text-amber-900 tracking-tight">Calculadora de Costos de Repostería</h1>
                </div>
            </header>

            <main className="container mx-auto p-4 sm:p-6 lg:p-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-1 flex flex-col gap-8">
                    <IngredientManager
                        ingredients={ingredientsList}
                        onAdd={() => openIngredientModal()}
                        onEdit={openIngredientModal}
                        onDelete={handleDeleteIngredient}
                        onListen={() => handleListen('ingredient')}
                    />
                    <RecipeManager
                        recipes={recipesList}
                        selectedRecipeId={selectedRecipeId}
                        onSelectRecipe={setSelectedRecipeId}
                        onAdd={() => openRecipeModal()}
                        onEdit={openRecipeModal}
                        onDelete={handleDeleteRecipe}
                        onListen={() => handleListen('recipe')}
                    />
                </div>

                <div className="lg:col-span-2">
                    {selectedRecipe ? (
                        <RecipeDetailView 
                            recipe={selectedRecipe}
                            ingredientsMap={ingredients}
                            recipesMap={recipes}
                            onUpdateDetails={handleUpdateRecipeDetails}
                            onAddItem={() => openItemModal()}
                            onEditItem={openItemModal}
                            onDeleteItem={handleDeleteItem}
                        />
                    ) : (
                        <Card className="h-full flex flex-col justify-center items-center text-center">
                            <Book size={64} className="text-gray-300 mb-4" />
                            <h2 className="text-2xl font-semibold text-gray-600">Seleccione una Receta</h2>
                            <p className="text-gray-400 mt-2">Elija una receta de la lista para ver sus detalles o cree una nueva.</p>
                        </Card>
                    )}
                </div>
            </main>
            
            <VoiceStatusIndicator status={voiceStatus} />
            
            <IngredientFormModal 
                isOpen={isIngredientModalOpen}
                onClose={() => setIngredientModalOpen(false)}
                onSave={handleSaveIngredient}
                ingredient={ingredientToEdit}
                isSubmitting={isSubmitting}
            />
            <RecipeFormModal
                isOpen={isRecipeModalOpen}
                onClose={() => setRecipeModalOpen(false)}
                onSave={handleSaveRecipe}
                recipe={recipeToEdit}
                isSubmitting={isSubmitting}
            />
            {selectedRecipe && (
                 <RecipeItemFormModal
                    isOpen={isItemModalOpen}
                    onClose={() => setItemModalOpen(false)}
                    onSave={handleSaveItem}
                    item={itemToEdit}
                    ingredients={ingredientsList}
                    recipes={recipesList.filter(r => r.id !== selectedRecipe.id)} // Prevent circular dependencies
                    isSubmitting={isSubmitting}
                />
            )}
        </div>
    );
}